var work='restaurants';
var workUrl=[
	'/',
	'./css/styles.css',
	'./data/restaurants.json',
	'./js/dbhelper.js',
	'./js/main.js',
	'./js/restaurant_info.js',
	'./img/one.jpg',
	'./img/two.jpg',
	'./img/three.jpg',
	'./img/four.jpg',
	'./img/five.jpg',
	'./img/six.jpg',
	'./img/seven.jpg',
	'./img/eight.jpg',
	'./img/nine.jpg',
	'./img/ten.jpg'
];

self.addEventListener("install",function(event){
	//performs install steps
	event.waitUntil(
		caches.open(work)
           .then(function(cache){
           	console.log('openend cache');
           	return cache.addAll(workUrl);
           })
		);
});

self.addEventListener('fetch',function(event){
	event.respondWith(
		caches.open(work).then(function(cache){
			return cache.match(event.request).then(
			function(response){
				return response || fetch(event.request).then(function(response){
					cache.put(event.request,response.clone(
						));
					return response;
				});
			  });
		})
	);
})
