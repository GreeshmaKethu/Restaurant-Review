# Project(Locations of Restaurants)

## contents
	*css
	*data
	*js
	*html

### css
	The stylings for all the contents including map,restaurants list....is applied on css files by using different id's and classes.

### data
	The information about the restaurants like location,comments,speciality...is provided in the data file.

### js
	The entire Java Script code for running tne functionality is written in all js files.

### html
	All the css,js files are mentioned in the html files.

## Dependencies
	As all the above files are interlinked to each other .The files are css,data,js,html.As the dependencies is like the code is written in the js file but that js file is mentioned in the html files.

##Instructions
	As to run this go to index.html file and open it in the chrome/some other websites,and main  thing is want to run the python while locating the addresses.And the entire thing is going to run in the 'localhost:8000'.As by clicking on the view details we can visit to that address and we can even run it in the offline too. 
